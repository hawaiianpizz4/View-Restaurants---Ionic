import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-restaurants',
  templateUrl: './restaurants.page.html',
  styleUrls: ['./restaurants.page.scss'],
})
export class RestaurantsPage implements OnInit {

  public restaurants=[
    {
      id:'1',
      numberRestaurant:'Restaurante 1',
      nameRestaurant:'Grill and Chill Fast Food', 
      link:"../../assets/img/imagen2.jpg",
      openClose:'Abierto - 24H',
      menu:'Menu del Restaurante',
      descripcionRestaurante:'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry'
    },
    {
      id:'2',
      numberRestaurant:'Restaurante 2',
      nameRestaurant:'Late Night Dine Right', 
      link:"../../assets/img/imagen2.jpg",
      openClose:'Abierto - 24H',
      menu:'Menu del Restaurante',
      descripcionRestaurante:'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry'
    },
    {
      id:'3',
      numberRestaurant:'Restaurante 3',
      nameRestaurant:'Chops & Hops', 
      link:"../../assets/img/imagen2.jpg",
      openClose:'Abierto - 24H',
      menu:'Menu del Restaurante',
      descripcionRestaurante:'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry'
    },
    {
      id:'4',
      numberRestaurant:'Restaurante 4',
      nameRestaurant:'Blazing Bean Roasters', 
      link:"../../assets/img/imagen2.jpg", 
      openClose:'Abierto - 24H',
      menu:'Menu del Restaurante',
      descripcionRestaurante:'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry'
    }
  ]
  



  constructor() { }

  ngOnInit() {
  }

  

}
